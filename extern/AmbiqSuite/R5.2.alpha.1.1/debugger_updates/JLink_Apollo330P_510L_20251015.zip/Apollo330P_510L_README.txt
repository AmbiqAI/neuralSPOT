10/15/2025

Interim J-Link installation for Apollo330P_510L.

Installation is the same for either Windows or Linux.

Note: J-Link v8.40 or later is required for this interim installation.


Windows or Linux:
-----------------
1. Install J-Link v8.40 or later.

2. Copy all files in this ZIP to the existing J-Link installation.
   The structure will look similar to the following.

   JLink_V840\JLinkDevices.xml
   JLink_V840\Devices\AmbiqMicro\Apollo330P_510L.JLinkScript
   JLink_V840\Devices\AmbiqMicro\Apollo330P_510L.elf

3. See PATH note below.



Windows and Linux:
------------------
In either case, be sure the "path" to the J-Link install occurs early in the
PATHing chain, particularly prior to other J-Link installations and/or IDE
tools such as Keil or IAR.



History:
10/15/25 - Official part numbers for Apollo330P and Apollo510L.
06/22/25 - First public release of J-Link support for Apollo330L_510L.
